@echo off
echo This is extra stuff about the Utils.
echo 1) you can edit the utills by going into the .ahk
echo        NOTE: you need "Ahk2Exe for AutoHotkey v1.1.37.02a0 -- Script to EXE Converter"
echo        NOTE 2: I AM NOT RESPONSIBLE IF YOU DO SOMETHING THAT HURTD YOUR DEVICE.
echo              ONLY CHANGE STUFF IF YOU KNOW WHAT YOURE DOING
echo                (Ya dont need that much knowledge of .ahk you just need to basics)
echo                    - Sans
echo 2) idk.
echo 3) I still dont know.
pause