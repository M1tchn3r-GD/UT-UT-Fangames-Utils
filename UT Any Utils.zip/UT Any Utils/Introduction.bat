@echo off
title How to Use Da Utils (Properly)

echo =========================================
echo     UNDERTALE UTILLS INSTRUCTIONS
echo =========================================
echo.
echo 1) Make sure Undertale / UT Fangame is open.
echo 2) Double-click the .exe file titled "UndertaleAnyUtills.exe" or run it through this batch
echo 3) Use the following hotkeys:
echo ------------------------------------------
echo    F1 - Start Up/Down spam
echo    F2 - Stop Up/Down spam
echo    F3 - Start text skipping (X then Z)
echo    F5 - Stop text skipping
echo -------------------------------------------
echo I will add more features soon
echo 4) To exit the macro completely, right-click the green H icon in the system tray and choose Exit.
echo 5) Make sure the game window is active while using the macro.

echo Press any key to launch the utils
pause > nul

REM Launch the macro
SET EXE_PATH="UndertaleAnyUtils.exe"
START "" %EXE_PATH%

echo Macro launched! Refer back to these instructions if needed.
pause