﻿#Requires AutoHotkey v2.0
#SingleInstance Force

running := false
textSkip := false

F1:: {
    global running
    running := true

    Loop 1000 {
        if !running
            break

        Send "{Up down}"
        Sleep 33
        Send "{Up up}"

        Send "{Down down}"
        Sleep 33
        Send "{Down up}"
    }

    running := false
}

F2:: {
    global running
    running := false
}

F3:: {
    global textSkip
    textSkip := true

    Loop 500 {
        if !textSkip
            break

        Send "{x down}"
        Sleep 33
        Send "{x up}"

        Send "{z down}"
        Sleep 33
        Send "{z up}"
    }

    textSkip := false
}

F5:: {
    global textSkip
    textSkip := false
}